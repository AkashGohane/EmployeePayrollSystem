﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeePayrollSystem
{
    public class Contractor : Employee
    {
        private const double HourlyRate = 40.0;

        public Contractor(string name, string employeeID)
            : base(name, employeeID, "Contractor") { }

        public override double CalculateSalary(double hoursWorked)
        {
            return hoursWorked * HourlyRate;
        }
    }
}
