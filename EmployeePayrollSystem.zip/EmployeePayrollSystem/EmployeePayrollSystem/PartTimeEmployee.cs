﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeePayrollSystem
{
    public class PartTimeEmployee : Employee
    {
        private const double HourlyRate = 20.0;

        public PartTimeEmployee(string name, string employeeID)
            : base(name, employeeID, "Part-Time") { }

        public override double CalculateSalary(double hoursWorked)
        {
            return hoursWorked * HourlyRate;
        }
    }
}
