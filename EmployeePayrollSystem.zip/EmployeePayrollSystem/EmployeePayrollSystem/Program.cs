﻿namespace EmployeePayrollSystem
{
    class Program
    {
        static Employee GetEmployeeDetails()
        {
            Console.Write("Enter employee name: ");
            string name = Console.ReadLine();

            Console.Write("Enter employee ID: ");
            string empID = Console.ReadLine();

            Console.WriteLine("Select employee type: ");
            Console.WriteLine("1. Full-Time");
            Console.WriteLine("2. Part-Time");
            Console.WriteLine("3. Contractor");
            string empType = Console.ReadLine();

            switch (empType)
            {
                case "1":
                    return new FullTimeEmployee(name, empID);
                case "2":
                    return new PartTimeEmployee(name, empID);
                case "3":
                    return new Contractor(name, empID);
                default:
                    Console.WriteLine("Invalid selection");
                    return null;
            }
        }

        static void Main(string[] args)
        {
            Employee employee = null;
            while (employee == null)
            {
                employee = GetEmployeeDetails();
            }

            Console.Write("Enter hours worked: ");
            double hoursWorked = Convert.ToDouble(Console.ReadLine());

            double salary = employee.CalculateSalary(hoursWorked);
            Console.WriteLine($"Employee {employee.Name} (ID: {employee.EmployeeID}, Type: {employee.EmployeeType}) earned ${salary:F2}");
        }
    }
}
