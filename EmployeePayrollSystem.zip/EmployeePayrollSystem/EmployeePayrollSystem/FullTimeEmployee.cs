﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeePayrollSystem
{
    public class FullTimeEmployee : Employee
    {
        private const double HourlyRate = 30.0;

        public FullTimeEmployee(string name, string employeeID)
            : base(name, employeeID, "Full-Time") { }

        public override double CalculateSalary(double hoursWorked)
        {
            return hoursWorked * HourlyRate;
        }
    }
}
