﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeePayrollSystem
{
    public abstract class Employee
    {
        public string Name { get; set; }
        public string EmployeeID { get; set; }
        public string EmployeeType { get; set; }

        protected Employee(string name, string employeeID, string employeeType)
        {
            Name = name;
            EmployeeID = employeeID;
            EmployeeType = employeeType;
        }

        public abstract double CalculateSalary(double hoursWorked);
    }
}
